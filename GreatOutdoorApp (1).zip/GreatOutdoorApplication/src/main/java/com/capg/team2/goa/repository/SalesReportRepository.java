package com.capg.team2.goa.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.capg.team2.goa.entity.SalesReportEntity;

public interface SalesReportRepository extends JpaRepository<SalesReportEntity, Long> {

}
