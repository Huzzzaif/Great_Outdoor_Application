package com.capg.team2.goa.exception;

public class CustomerNotFoundException extends Exception {

}
