package com.capg.team2.goa.exception;

public class SalesReportException extends Exception{

}
