package com.capg.team2.goa.exception;

public class ProductException extends Exception{

}
