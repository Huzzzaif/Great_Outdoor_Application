package com.capg.team2.goa.exception;

public class WishlistException extends Exception {

	
}
