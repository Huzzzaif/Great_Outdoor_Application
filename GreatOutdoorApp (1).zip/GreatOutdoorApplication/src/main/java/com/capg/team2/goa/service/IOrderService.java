package com.capg.team2.goa.service;

public interface IOrderService {

}
