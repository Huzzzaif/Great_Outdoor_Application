package com.capg.team2.goa.exception;

public class CustomerAlreadyExistsException extends Exception {

}
